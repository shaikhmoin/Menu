//
//  ViewController.swift
//  MyTask1
//
//  Created by Parghi Infotech on 03/01/18.
//  Copyright © 2018 Parghi Infotech. All rights reserved.
//

import UIKit
import Photos

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBOutlet weak var imageProfile: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print(APPDELEGATE.imageXPosition)
        print(APPDELEGATE.imageYPosition)
        print(APPDELEGATE.imageWidth)
        print(APPDELEGATE.imageHeight)
        
        // Image XPosition
        if APPDELEGATE.imageXPosition == nil || APPDELEGATE.imageXPosition == 0
        {
            imageProfile.frame = CGRect(x: imageProfile.frame.origin.x, y: imageProfile.frame.origin.y, width: imageProfile.frame.width, height: imageProfile.frame.height)
        }
        else
        {
            imageProfile.frame = CGRect(x: CGFloat(APPDELEGATE.imageXPosition), y: imageProfile.frame.origin.y, width: imageProfile.frame.width, height: imageProfile.frame.height)
        }
        
        // Image YPosition
        if APPDELEGATE.imageYPosition == nil || APPDELEGATE.imageYPosition == 0
        {
            imageProfile.frame = CGRect(x: imageProfile.frame.origin.x, y: imageProfile.frame.origin.y, width: imageProfile.frame.width, height: imageProfile.frame.height)
        }
        else
        {
            imageProfile.frame = CGRect(x: imageProfile.frame.origin.x, y: CGFloat(APPDELEGATE.imageYPosition), width: imageProfile.frame.width, height: imageProfile.frame.height)
        }
        
        // Image Width
        if APPDELEGATE.imageWidth == nil || APPDELEGATE.imageWidth == 0
        {
            imageProfile.frame = CGRect(x: imageProfile.frame.origin.x, y: imageProfile.frame.origin.y, width: imageProfile.frame.width, height: imageProfile.frame.height)
        }
        else
        {
              imageProfile.frame = CGRect(x: imageProfile.frame.origin.x, y: imageProfile.frame.origin.y, width: CGFloat(APPDELEGATE.imageWidth), height: imageProfile.frame.height)
        }
        
        // Image Height
        if APPDELEGATE.imageHeight == nil || APPDELEGATE.imageHeight == 0
        {
            imageProfile.frame = CGRect(x: imageProfile.frame.origin.x, y: imageProfile.frame.origin.y, width: imageProfile.frame.width, height: imageProfile.frame.height)
        }
        else
        {
            imageProfile.frame = CGRect(x: imageProfile.frame.origin.x, y: imageProfile.frame.origin.y, width: imageProfile.frame.width, height: CGFloat(APPDELEGATE.imageHeight))
        }
        
        // Image Border Color
        if APPDELEGATE.imageBorderColor != nil
        {
            imageProfile.layer.borderColor = APPDELEGATE.imageBorderColor.cgColor
        }
        else
        {
            imageProfile.layer.borderColor = UIColor.clear.cgColor
        }
        
        // Image Border Width
        if  APPDELEGATE.imageBorderWidth != nil
        {
            let borderStringToCgFloat = CGFloat((APPDELEGATE.imageBorderWidth as NSString).floatValue)
            imageProfile.layer.borderWidth =  borderStringToCgFloat
        }
    }
    
    //MARK: buttonCircleClicked
    @IBAction func buttonCircleClicked(_ sender: Any) {
        imageProfile.layer.borderWidth = 1
        imageProfile.layer.masksToBounds = false
        imageProfile.layer.borderColor = UIColor.black.cgColor
        imageProfile.layer.cornerRadius = imageProfile.frame.height/2
        imageProfile.clipsToBounds = true
        let addListVCnavigation = self.storyboard?.instantiateViewController(withIdentifier: "AddListDataViewController") as! AddListDataViewController
        self.navigationController?.pushViewController(addListVCnavigation, animated: true)
    }
    
    //MARK: buttonSquareclicked
    @IBAction func buttonSquareclicked(_ sender: Any) {
        imageProfile.layer.borderWidth = 1
        imageProfile.layer.masksToBounds = false
        imageProfile.layer.borderColor = UIColor.black.cgColor
        imageProfile.layer.cornerRadius = 0
        imageProfile.clipsToBounds = true
        let addListVCnavigation = self.storyboard?.instantiateViewController(withIdentifier: "AddListDataViewController")
        self.navigationController?.pushViewController(addListVCnavigation!, animated: true)
    }
    
    //MARK: buttonOpenImage
    @IBAction func buttonOpenImage(_ sender: Any) {

        let pickerView: UIImagePickerController = UIImagePickerController()
        pickerView.allowsEditing = false
        pickerView.modalPresentationStyle = .popover
        pickerView.sourceType = UIImagePickerControllerSourceType.photoLibrary
        pickerView.delegate = self
        self.present(pickerView, animated: true, completion: nil)
    }
    
    // MARK: image Picker Methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {

        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageProfile.contentMode = .scaleAspectFill
            imageProfile.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
  
}

