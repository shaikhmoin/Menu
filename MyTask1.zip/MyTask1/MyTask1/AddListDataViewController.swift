//
//  AddListDataViewController.swift
//  MyTask1
//
//  Created by Parghi Infotech on 03/01/18.
//  Copyright © 2018 Parghi Infotech. All rights reserved.
//

import UIKit

class AddListDataViewController: UIViewController {

    @IBOutlet weak var textfieldXPosition: UITextField!
    @IBOutlet weak var textfieldYPosition: UITextField!
    @IBOutlet weak var textfieldWidth: UITextField!
    @IBOutlet weak var textfieldHeight: UITextField!
    @IBOutlet weak var textfieldBorderColor: UITextField!
    @IBOutlet weak var sliderBorderWidth: UISlider!
    @IBOutlet weak var lableSliderValue: UILabel!
    
    var xPosition = ""
    var yPosition = ""
    var width = ""
    var height = ""
    var borderColor = ""
    var borderWidth : String!
 
    override func viewDidLoad() {
        super.viewDidLoad()

        sliderBorderWidth.minimumValue = 0
        sliderBorderWidth.maximumValue = 100
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonSubmit(_ sender: Any) {
        // XPosition
        self.xPosition = textfieldXPosition.text!
        let xPositionInFloat = CGFloat((xPosition as NSString).floatValue)
        
        // YPosition
        self.yPosition = textfieldYPosition.text!
        let yPositionInFloat = CGFloat((yPosition as NSString).floatValue)
        
        // Width
        self.width = textfieldWidth.text!
        let widthInFloat = CGFloat((width as NSString).floatValue)
        
        // Height
        self.height = textfieldHeight.text!
        let heightInFloat = CGFloat((height as NSString).floatValue)
        
        // BorderColor
        self.borderColor = textfieldBorderColor.text!
        if let color = getColor(borderColor) {
            print(color)
            APPDELEGATE.imageBorderColor = color
        } else {
            print("color with name:\(borderColor) is unavailable")
        }
        
        let mainVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        
        APPDELEGATE.imageXPosition = xPositionInFloat
        APPDELEGATE.imageYPosition = yPositionInFloat
        APPDELEGATE.imageWidth = widthInFloat
        APPDELEGATE.imageHeight = heightInFloat
  
        navigationController?.popViewController(animated: true)
    }
    
    //MARK: sliderclicked
    @IBAction func sliderclicked(_ sender: Any) {

        self.borderWidth = String(sliderBorderWidth.value)
        print(self.borderWidth)
        lableSliderValue.text = self.borderWidth
        APPDELEGATE.imageBorderWidth = self.borderWidth
    }
    
    func getColor(_ name: String) -> UIColor? {
        let selector = Selector("\(name)Color")
        if UIColor.self.responds(to: selector) {
            let color = UIColor.self.perform(selector).takeUnretainedValue()
            return (color as! UIColor)
        } else {
            return nil
        }
    }
}
